"""Dependent-return uncertainty estimates and conservative research screening.

These diagnostics describe recorded experiments. They never authorize live
trading, and neither bootstrap intervals nor screening thresholds are promises.
"""
from __future__ import annotations

import math
import numpy as np
import pandas as pd


def _positive_integer(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value <= 0:
        raise ValueError(f'{name} must be a positive integer')
    return int(value)


def _finite_number(value, name):
    if isinstance(value, bool):
        raise ValueError(f'{name} must be a finite number')
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f'{name} must be a finite number') from exc
    if not math.isfinite(result):
        raise ValueError(f'{name} must be a finite number')
    return result


def block_bootstrap_mean_ci(returns: np.ndarray | list[float], block_length: int = 5,
                            n_bootstrap: int = 5000, alpha: float = .05,
                            seed: int = 17) -> dict:
    """Percentile CI using uniformly sampled circular contiguous blocks.

    Blocks wrap around the sample and each replicate is truncated to the original
    number of sessions. Approximate inference assumes reasonably stable daily
    returns and that the chosen block captures relevant serial dependence.
    """
    values = np.asarray(returns, dtype=float)
    if values.ndim != 1 or not len(values) or not np.isfinite(values).all():
        raise ValueError('returns must be a nonempty finite one-dimensional array')
    block_length = _positive_integer(block_length, 'block_length')
    n_bootstrap = _positive_integer(n_bootstrap, 'n_bootstrap')
    alpha = _finite_number(alpha, 'alpha')
    if not 0 < alpha < 1:
        raise ValueError('alpha must lie strictly between zero and one')
    if isinstance(seed, bool) or not isinstance(seed, (int, np.integer)) or seed < 0:
        raise ValueError('seed must be a nonnegative integer')
    rng = np.random.default_rng(seed)
    n = len(values)
    # At most n offsets are needed even when the requested block exceeds n.
    offsets = np.arange(min(block_length, n))
    blocks_per_sample = math.ceil(n / block_length)
    estimates = np.empty(n_bootstrap)
    # Bound temporary memory; draws remain deterministic for a fixed seed.
    batch_size = max(1, min(256, 1_000_000 // n))
    for start in range(0, n_bootstrap, batch_size):
        count = min(batch_size, n_bootstrap - start)
        starts = rng.integers(0, n, size=(count, blocks_per_sample))
        indices = ((starts[:, :, None] + offsets) % n).reshape(count, -1)[:, :n]
        estimates[start:start + count] = values[indices].mean(axis=1)
    lower, upper = np.quantile(estimates, [alpha / 2, 1 - alpha / 2])
    expected_samples_per_tail = float(n_bootstrap * (alpha / 2))
    inference_failures = []
    if block_length >= n:
        inference_failures.append('block_length_not_less_than_observations')
    if expected_samples_per_tail < 10:
        inference_failures.append('insufficient_bootstrap_tail_samples')
    return {'mean': float(values.mean()), 'lower': float(lower), 'upper': float(upper),
            'alpha': alpha, 'block_length': block_length, 'n_observations': n,
            'n_bootstrap': n_bootstrap, 'method': 'circular_block_bootstrap_percentile',
            'inference_valid': not inference_failures, 'inference_failures': inference_failures,
            'expected_samples_per_tail': expected_samples_per_tail, 'minimum_expected_tail_samples': 10,
            'inference_policy': 'Screening checks only: block_length < n_observations and at least 10 expected bootstrap draws per adjusted tail. Passing is not proof of statistical validity.',
            'assumptions': 'Approximate; stable returns and adequate block length for dependence. Not a future-profit probability.'}


def summarize_performance(equity: pd.DataFrame, trades: pd.DataFrame,
                          config: dict | None = None) -> dict:
    """Summarize every represented session, including days with no trades."""
    cfg = {'initial_cash': 10000., 'bootstrap_samples': 5000, 'block_length': 5,
           'alpha': .05, 'family_size': 12, 'seed': 17}
    cfg.update(config or {})
    initial = _finite_number(cfg['initial_cash'], 'initial_cash')
    if initial <= 0:
        raise ValueError('initial_cash must be positive')
    family = _positive_integer(cfg['family_size'], 'family_size')
    alpha = _finite_number(cfg['alpha'], 'alpha')
    if not 0 < alpha < 1:
        raise ValueError('alpha must lie strictly between zero and one')
    required = {'session_date', 'equity', 'daily_return', 'net_pnl', 'trade_count'}
    if equity.empty or not required.issubset(equity.columns):
        raise ValueError('Equity must contain complete per-session records')
    frame = equity.copy()
    dates = pd.to_datetime(frame['session_date'], errors='raise')
    if dates.duplicated().any() or not dates.is_monotonic_increasing:
        raise ValueError('Equity session dates must be unique and chronological')
    numeric = frame[['equity', 'daily_return', 'net_pnl', 'trade_count']].to_numpy(dtype=float)
    if not np.isfinite(numeric).all() or (numeric[:, 0] < 0).any() or (numeric[:, 1] < -1).any():
        raise ValueError('Equity records must contain finite valid account values')
    counts = numeric[:, 3]
    if (counts < 0).any() or (counts != np.floor(counts)).any():
        raise ValueError('trade_count must contain nonnegative integers')
    returns = numeric[:, 1]
    balances = np.concatenate([[initial], numeric[:, 0]])
    peaks = np.maximum.accumulate(balances)
    max_drawdown = float(np.max(1 - balances / peaks))
    iso = dates.dt.isocalendar()
    frame['_week'] = list(zip(iso['year'].astype(int), iso['week'].astype(int)))
    frame['_return'] = returns
    frame['_active'] = counts > 0
    grouped = frame.groupby('_week', sort=True)
    weekly = grouped['_return'].apply(lambda values: float(np.prod(1 + values.to_numpy()) - 1))
    active_week = grouped['_active'].any()
    longest = current = 0
    for active in counts > 0:
        current = 0 if active else current + 1
        longest = max(longest, current)
    if trades.empty:
        profits = np.array([], dtype=float)
        trade_returns = np.array([], dtype=float)
        total_fees = 0.
    else:
        trade_required = {'net_pnl', 'net_return', 'entry_fee', 'exit_fee'}
        if not trade_required.issubset(trades.columns):
            raise ValueError('Trades must contain net outcomes and fees')
        trade_numeric = trades[['net_pnl', 'net_return', 'entry_fee', 'exit_fee']].to_numpy(dtype=float)
        if not np.isfinite(trade_numeric).all() or (trade_numeric[:, 2:] < 0).any():
            raise ValueError('Trade outcomes/fees must be finite and fees nonnegative')
        profits, trade_returns = trade_numeric[:, 0], trade_numeric[:, 1]
        total_fees = float(trade_numeric[:, 2:].sum())
    gains = float(profits[profits > 0].sum())
    losses = float(-profits[profits < 0].sum())
    net_return = float(numeric[-1, 0] / initial - 1)
    with np.errstate(over='ignore', invalid='ignore'):
        annualized = float(np.power(1 + net_return, 252 / len(frame)) - 1)
    ci = block_bootstrap_mean_ci(returns, cfg['block_length'], cfg['bootstrap_samples'], alpha / family, cfg['seed'])
    return {'evaluation_sessions': len(frame), 'evaluation_weeks': len(weekly),
            'net_return': net_return, 'annualized_return': annualized if math.isfinite(annualized) else None,
            'annualization': 'Approximate 252-session convention; extrapolation, not a forecast.',
            'max_drawdown': max_drawdown, 'worst_day': float(returns.min()), 'worst_week': float(weekly.min()),
            'win_rate': float(np.mean(profits > 0)) if len(profits) else None, 'trades': len(profits),
            'active_day_fraction': float(np.mean(counts > 0)), 'active_week_fraction': float(active_week.mean()),
            'longest_no_trade_sessions': int(longest), 'mean_daily_return': float(returns.mean()),
            'mean_trade_net_return': float(trade_returns.mean()) if len(trade_returns) else None,
            'profit_factor': gains / losses if losses > 0 else None,
            'total_fees': total_fees, 'total_net_pnl': float(numeric[:, 2].sum()), 'bootstrap_ci': ci,
            'family_size': family, 'nominal_alpha': alpha,
            'inference_valid': ci['inference_valid'], 'inference_failures': list(ci['inference_failures']),
            'multiple_testing_adjustment': 'Approximate Bonferroni alpha/family_size for the recorded bounded family. Does not protect against unrecorded or adaptive searches.',
            'tail_and_concentration': {'worst_trade_net_return': float(trade_returns.min()) if len(trade_returns) else None,
                'best_day': float(returns.max()),
                'best_day_share_of_positive_daily_pnl': float(max(0., numeric[:, 2].max()) / numeric[numeric[:, 2] > 0, 2].sum()) if (numeric[:, 2] > 0).any() else None}}


def assess_evidence(metrics: dict, data_kind: str, phase: str, criteria: dict | None = None,
                    provenance_verified: bool = False) -> dict:
    """Apply illustrative frozen screening criteria; never return live permission."""
    cfg = {'min_evaluation_sessions': 60, 'min_trades': 30, 'min_active_week_fraction': .6,
           'max_drawdown': .1, 'min_mean_daily_return': 0.}
    cfg.update(criteria or {})
    if data_kind not in {'real', 'synthetic'}:
        raise ValueError('data_kind must be real or synthetic')
    for key in ('min_evaluation_sessions', 'min_trades'):
        cfg[key] = _positive_integer(cfg[key], key)
    for key in ('min_active_week_fraction', 'max_drawdown', 'min_mean_daily_return'):
        cfg[key] = _finite_number(cfg[key], key)
    if not 0 <= cfg['min_active_week_fraction'] <= 1 or not 0 <= cfg['max_drawdown'] <= 1:
        raise ValueError('Frequency and drawdown criteria must lie in [0, 1]')

    def metric(name):
        try:
            value = float(metrics.get(name))
            return value if math.isfinite(value) else None
        except (TypeError, ValueError):
            return None

    checks = []
    for name, threshold in [('evaluation_sessions', cfg['min_evaluation_sessions']),
                            ('trades', cfg['min_trades']),
                            ('active_week_fraction', cfg['min_active_week_fraction'])]:
        value = metric(name)
        if value is None or value < threshold:
            checks.append(f'{name} missing, nonfinite or below {threshold}')
    drawdown = metric('max_drawdown')
    if drawdown is None or drawdown < 0 or drawdown > cfg['max_drawdown']:
        checks.append('max_drawdown missing, invalid or above configured maximum')
    net = metric('net_return')
    if net is None or net <= 0:
        checks.append('net_return must be finite and strictly positive')
    try:
        lower = float(metrics.get('bootstrap_ci', {}).get('lower'))
    except (TypeError, ValueError, AttributeError):
        lower = float('nan')
    if not math.isfinite(lower) or lower <= cfg['min_mean_daily_return']:
        checks.append('bootstrap lower bound must be strictly above min_mean_daily_return')
    # Missing diagnostics cannot silently retain the older permissive gate.
    ci = metrics.get('bootstrap_ci')
    valid_inference = (metrics.get('inference_valid') is True
                       and metrics.get('inference_failures') == []
                       and isinstance(ci, dict)
                       and ci.get('inference_valid') is True
                       and ci.get('inference_failures') == [])
    if not valid_inference:
        checks.append('bootstrap inference validity diagnostics missing or failed screening checks')
    if provenance_verified is not True:
        checks.append('Real-data provenance has not been independently verified')
    if data_kind == 'synthetic':
        checks.append('Synthetic observations cannot establish a qualifying trading strategy')
        status = 'SYNTHETIC_DEMO'
    elif checks:
        status = 'RESEARCH_ONLY'
    else:
        status = 'PAPER_CANDIDATE' if phase == 'holdout' else 'HISTORICAL_CANDIDATE'
    return {'status': status, 'eligible_for_live': False, 'data_kind': data_kind, 'phase': str(phase),
            'failed_checks': checks, 'criteria': cfg, 'inference_valid': valid_inference,
            'caveats': ['Illustrative screening assumptions; thresholds are not statistical laws or a personal risk mandate.',
                        'Circular block intervals are approximate conditional estimates, not probabilities of future profit.',
                        'Inference screening requires blocks shorter than the sample and at least 10 expected bootstrap draws per adjusted tail; these checks do not establish stability or adequate dependence modeling.',
                        'Family correction covers the recorded bounded search only; adaptive searches and regime changes remain risks.',
                        'Historical drawdown does not cap future loss; bar execution approximations can miss real costs.',
                        'A subsequent frozen prospective paper evaluation is required. This version never authorizes live trading.']}
