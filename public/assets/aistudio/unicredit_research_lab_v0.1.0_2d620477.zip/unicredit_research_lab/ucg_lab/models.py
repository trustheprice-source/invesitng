"""Numerical forecasts and causal historical examples.

Future outcomes are permitted as training labels only after they finish. Neither
preprocessing nor neighbor distances use evaluation-period observations.
"""
from __future__ import annotations

from datetime import date
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler


def _times(values, name: str, allow_missing: bool = False) -> pd.Series:
    parsed = []
    for value in values:
        if pd.isna(value):
            if allow_missing:
                parsed.append(pd.NaT)
                continue
            raise ValueError(f'{name} contains missing timestamps')
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            raise ValueError(f'{name} must be timezone-aware')
        parsed.append(timestamp.tz_convert('UTC'))
    return pd.Series(pd.to_datetime(parsed, utc=True), index=getattr(values, 'index', None))


def _matrix(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns or len(columns) != len(set(columns)):
        raise ValueError('feature_columns must be a nonempty unique list')
    forbidden = {'target_return', 'label_end', 'decision_time', 'session_date'}
    if forbidden.intersection(columns):
        raise ValueError('Targets and timestamps cannot be numerical features')
    try:
        matrix = frame.loc[:, columns].to_numpy(dtype=float, copy=True)
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError('Missing or nonnumeric feature columns') from exc
    if np.isinf(matrix).any():
        raise ValueError('Infinite feature values are not allowed')
    return matrix


def _impute(train: np.ndarray, other: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    medians = np.array([float(np.median(col[~np.isnan(col)])) if (~np.isnan(col)).any() else 0.
                        for col in train.T])
    return np.where(np.isnan(train), medians, train), np.where(np.isnan(other), medians, other)


def fit_predict_model(train: pd.DataFrame, test: pd.DataFrame, feature_columns: list[str],
                      model_name: str = 'ridge', parameters: dict | None = None) -> np.ndarray:
    """Fit on completed training outcomes and return deterministic numeric scores.

    The boundary is the earliest test decision, with equality excluded. A label
    with no outcome is discarded; an invalid timestamp or infinity is an error.
    """
    parameters = dict(parameters or {})
    if model_name not in {'ridge', 'lightgbm'}:
        raise ValueError(f'Unknown model: {model_name}')
    if test.empty:
        raise ValueError('Test data must contain at least one decision')
    required = {'target_return', 'label_end', 'decision_time'}
    if not required.issubset(train.columns) or 'decision_time' not in test:
        raise ValueError('Missing model outcome/timestamp columns')
    train_matrix = _matrix(train, feature_columns)
    test_matrix = _matrix(test, feature_columns)
    test_times = _times(test['decision_time'], 'test.decision_time')
    train_times = _times(train['decision_time'], 'train.decision_time')
    label_times = _times(train['label_end'], 'label_end', allow_missing=True)
    targets = pd.to_numeric(train['target_return'], errors='raise').to_numpy(dtype=float)
    if np.isinf(targets).any():
        raise ValueError('Infinite targets are not allowed')
    known = label_times.notna()
    if (label_times[known] < train_times[known]).any():
        raise ValueError('label_end cannot precede decision_time')
    boundary = test_times.min()
    eligible = ((label_times < boundary) & (train_times < boundary)).to_numpy() & np.isfinite(targets)
    if int(eligible.sum()) < 30:
        raise ValueError('At least 30 valid completed training rows are required after purging')
    xtrain, xtest = _impute(train_matrix[eligible], test_matrix)
    scaler = StandardScaler()
    xtrain = scaler.fit_transform(xtrain)
    xtest = scaler.transform(xtest)
    if model_name == 'ridge':
        alpha = parameters.pop('alpha', 10.0)
        if parameters:
            raise ValueError(f'Unsupported ridge parameters: {sorted(parameters)}')
        if isinstance(alpha, bool) or not np.isfinite(alpha) or alpha < 0:
            raise ValueError('Ridge alpha must be finite and nonnegative')
        model = Ridge(alpha=float(alpha), solver='svd')
    else:
        try:
            from lightgbm import LGBMRegressor
        except ImportError as exc:
            raise ImportError('LightGBM is unavailable; install the optional lightgbm dependency explicitly. No fallback model was used.') from exc
        # Fixed seed and single-threaded CPU learning make the challenger repeatable.
        defaults = {'n_estimators': 100, 'max_depth': 3, 'num_leaves': 7, 'learning_rate': .05,
                    'random_state': 17, 'n_jobs': 1, 'verbosity': -1, 'deterministic': True,
                    'force_col_wise': True, 'device_type': 'cpu'}
        defaults.update(parameters)
        defaults.update(n_jobs=1, deterministic=True, force_col_wise=True, device_type='cpu')
        model = LGBMRegressor(**defaults)
    model.fit(xtrain, targets[eligible])
    predictions = np.asarray(model.predict(xtest), dtype=float)
    if predictions.shape != (len(test),) or not np.isfinite(predictions).all():
        raise ValueError('Model did not return one finite score per evaluation row')
    return predictions


def walk_forward_splits(session_dates: list[str], train_sessions: int,
                        test_sessions: int) -> list[tuple[list[str], list[str]]]:
    """Rolling chronological training windows with disjoint evaluation blocks."""
    for name, value in [('train_sessions', train_sessions), ('test_sessions', test_sessions)]:
        if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value <= 0:
            raise ValueError(f'{name} must be a positive integer')
    dates = list(session_dates)
    if any(not isinstance(d, str) or date.fromisoformat(d).isoformat() != d for d in dates):
        raise ValueError('Session dates must be canonical ISO dates')
    if dates != sorted(set(dates)):
        raise ValueError('Session dates must be chronologically sorted and unique')
    return [(dates[start - train_sessions:start], dates[start:start + test_sessions])
            for start in range(train_sessions, len(dates), test_sessions)]


def find_analogs(train: pd.DataFrame, query: pd.Series, feature_columns: list[str],
                 max_cases: int = 10) -> list[dict]:
    """Find completed historical neighbors; examples provide no independent proof."""
    if isinstance(max_cases, bool) or not isinstance(max_cases, (int, np.integer)) or max_cases <= 0:
        raise ValueError('max_cases must be a positive integer')
    query_time = _times(pd.Series([query.get('decision_time')]), 'query.decision_time').iloc[0]
    if train.empty:
        return []
    required = {'decision_time', 'label_end', 'target_return', 'session_date'}
    if not required.issubset(train.columns):
        raise ValueError('Missing historical-example outcome/timestamp columns')
    decisions = _times(train['decision_time'], 'decision_time')
    ends = _times(train['label_end'], 'label_end', allow_missing=True)
    eligible = (decisions < query_time) & (ends < query_time)
    history = train.loc[eligible].copy()
    if history.empty:
        return []
    targets = pd.to_numeric(history['target_return'], errors='raise').to_numpy(dtype=float)
    if np.isinf(targets).any():
        raise ValueError('Infinite historical outcomes are not allowed')
    history = history.loc[np.isfinite(targets)].copy()
    if history.empty:
        return []
    xtrain = _matrix(history, feature_columns)
    xquery = _matrix(pd.DataFrame([query]), feature_columns)
    xtrain, xquery = _impute(xtrain, xquery)
    scaler = StandardScaler()
    normalized = scaler.fit_transform(xtrain)
    distances = np.sqrt(np.square(normalized - scaler.transform(xquery)[0]).sum(axis=1))
    if not np.isfinite(distances).all():
        raise ValueError('Nonfinite historical-example distance')
    history['_distance'] = distances
    history['_decision'] = _times(history['decision_time'], 'decision_time')
    history = history.sort_values(['_distance', '_decision'], kind='stable')
    history = history.drop_duplicates('session_date', keep='first').head(max_cases)
    return [{'decision_time': pd.Timestamp(row['decision_time']).isoformat(),
             'label_end': pd.Timestamp(row['label_end']).isoformat(),
             'session_date': str(row['session_date']), 'distance': float(row['_distance']),
             'target_return': float(row['target_return'])} for _, row in history.iterrows()]
