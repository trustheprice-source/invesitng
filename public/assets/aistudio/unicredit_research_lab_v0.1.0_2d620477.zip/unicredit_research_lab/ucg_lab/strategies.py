"""Three fixed, illustrative rule hypotheses; thresholds are not evidence of edge.

trend_pullback: rising 60-minute trend, price at/above VWAP, recovery in
this completed bar after a nonpositive immediately previous session bar.
opening_breakout: completed price strictly above the fixed 30-minute range.
mean_reversion: negative completed return while sufficiently below VWAP.
All rules require a valid prior-session relative-volume baseline.
"""
import math
import pandas as pd


RULE_DEFAULTS = {
    'trend_pullback': {'min_rvol': 1.2, 'min_return_60m': 0., 'min_vwap_distance': 0.,
                       'min_return_5m': 0., 'max_previous_return_5m': 0.},
    'opening_breakout': {'min_rvol': 1.5, 'breakout_buffer_pct': 0.},
    'mean_reversion': {'min_rvol': 1., 'max_vwap_distance': -.005, 'max_return_5m': 0.},
}


def generate_rule_signals(features, name, parameters=None):
    """Return one binary score per row, without mutating features.

    Thresholds are explicit via RULE_DEFAULTS. Unknown parameter keys fail rather
    than silently changing the experiment. Return and breakout comparisons are
    strict; relative-volume and VWAP boundaries are inclusive.
    """
    if name not in RULE_DEFAULTS:
        raise ValueError(f'unknown rule: {name}')
    p = dict(RULE_DEFAULTS[name])
    supplied = parameters or {}
    if set(supplied) - set(p):
        raise ValueError(f'unknown {name} parameters: {sorted(set(supplied) - set(p))}')
    p.update(supplied)
    if any(isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v) for v in p.values()):
        raise ValueError('rule thresholds must be finite numbers')
    if p['min_rvol'] < 0 or p.get('breakout_buffer_pct', 0) < 0:
        raise ValueError('volume and breakout thresholds must be nonnegative')
    f = features
    required = {'decision_time','rvol_ready','rvol'}
    if name == 'trend_pullback':
        required |= {'session_date','return_60m','vwap_distance','return_5m'}
    elif name == 'opening_breakout':
        required |= {'opening_range_ready','last_price','opening_range_high'}
    else:
        required |= {'vwap_distance','return_5m'}
    if required - set(f.columns):
        raise ValueError(f'missing rule columns: {sorted(required - set(f.columns))}')
    times = pd.to_datetime(f.decision_time, utc=True)
    if times.duplicated().any() or not times.is_monotonic_increasing:
        raise ValueError('decisions must be unique and chronological')
    numeric = required - {'decision_time','session_date','rvol_ready','opening_range_ready'}
    for column in numeric:
        values = pd.to_numeric(f[column], errors='raise')
        if values.dropna().map(lambda value: not math.isfinite(value)).any():
            raise ValueError(f'infinite rule input: {column}')
    valid = f.rvol_ready.eq(True) & f.rvol.ge(p['min_rvol'])
    if name == 'trend_pullback':
        previous = f.groupby('session_date', sort=False)['return_5m'].shift(1)
        valid &= (f.return_60m.gt(p['min_return_60m']) & f.vwap_distance.ge(p['min_vwap_distance'])
                  & f.return_5m.gt(p['min_return_5m']) & previous.le(p['max_previous_return_5m']))
    elif name == 'opening_breakout':
        valid &= f.opening_range_ready.eq(True) & f.last_price.gt(f.opening_range_high * (1 + p['breakout_buffer_pct']))
    else:
        valid &= f.vwap_distance.le(p['max_vwap_distance']) & f.return_5m.lt(p['max_return_5m'])
    return pd.DataFrame({'decision_time': f.decision_time.copy(), 'score': valid.fillna(False).astype(float)})
