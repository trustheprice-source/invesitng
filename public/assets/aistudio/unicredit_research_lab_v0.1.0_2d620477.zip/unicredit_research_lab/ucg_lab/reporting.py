"""Portable local reports. All data-derived strings are escaped."""

from __future__ import annotations

import html
import json
import math
from pathlib import Path


def _escape(value):
    return html.escape(str(value), quote=True)


def _percent(value):
    return '—' if value is None else f'{float(value):.2%}'


def _curve(rows):
    values = [float(row['equity']) for row in rows if math.isfinite(float(row['equity']))]
    if not values:
        return '<p>No evaluated sessions.</p>'
    low, high = min(values), max(values)
    span = max(high - low, abs(high) * 0.001, 0.01)
    points = ' '.join(f'{20 + 700 * i / max(len(values)-1,1):.2f},{145 - 120*(v-low)/span:.2f}' for i,v in enumerate(values))
    return f'<svg viewBox="0 0 740 170" role="img" aria-label="Simulated account equity by evaluated session"><line x1="20" y1="145" x2="720" y2="145" stroke="#d9e0e7"/><polyline points="{points}" fill="none" stroke="#246a77" stroke-width="2.5"/><text x="20" y="165" font-size="11" fill="#52616f">Session sequence · equity range €{low:,.2f} to €{high:,.2f}</text></svg>'


def write_report(report: dict, out: str | Path) -> dict:
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    json_path, html_path = out / 'report.json', out / 'report.html'
    json_path.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    synthetic = report.get('data_kind') == 'synthetic'
    banner = 'SYNTHETIC DEMONSTRATION — invented prices, not UniCredit performance' if synthetic else 'RESEARCH / PAPER ONLY — no live trading authorization'
    cards = []
    rows = []
    for item in report.get('results', []):
        metrics, evidence = item['metrics'], item['evidence']
        name = item['candidate']['id']
        ci = metrics.get('bootstrap_ci', {})
        rows.append('<tr>' + ''.join(f'<td>{_escape(value)}</td>' for value in [
            name, evidence['status'], _percent(metrics.get('net_return')),
            metrics.get('trades', 0), _percent(metrics.get('active_week_fraction')),
            _percent(metrics.get('max_drawdown')),
            f"{_percent(ci.get('lower'))} to {_percent(ci.get('upper'))}",
        ]) + '</tr>')
        failed = evidence.get('failed_checks', [])
        cards.append(f'<section><h2>{_escape(name)}</h2><p class="muted">{_escape(evidence["status"])} · {_escape(metrics.get("evaluation_sessions",0))} evaluated sessions</p>{_curve(item.get("equity",[]))}<p>Unmet checks: {_escape(", ".join(map(str,failed)) if failed else "none under these screening assumptions")}</p><details><summary>Evidence assumptions and diagnostics</summary><pre>{_escape(json.dumps({"metrics":metrics,"evidence":evidence},indent=2,allow_nan=False))}</pre></details></section>')
    failures = ''.join(f'<li>{_escape(x)}</li>' for x in report.get('failures', []))
    page = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>UniCredit Research Lab</title>
<style>body{{margin:0;background:#f3f5f7;color:#182b38;font:15px/1.6 system-ui,sans-serif}}main{{max-width:1150px;margin:40px auto;padding:0 24px 50px}}h1{{font-size:34px;line-height:1.15}}h2{{font-size:21px}}.eyebrow{{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#39707a}}.banner{{padding:16px 20px;background:#fff1d5;border:1px solid #e7c987;border-radius:12px;font-weight:650}}section{{background:white;border:1px solid #dce3e8;border-radius:14px;padding:22px;margin:22px 0}}.muted{{color:#5c6c79}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{padding:12px;text-align:left;border-bottom:1px solid #e2e7eb;white-space:nowrap}}th{{color:#52616f}}svg{{width:100%;max-height:240px}}pre{{white-space:pre-wrap;word-break:break-word;font-size:12px;background:#f7f9fa;padding:16px;border-radius:8px}}footer{{font-size:13px;color:#5c6c79}}summary{{cursor:pointer;font-weight:600}}</style></head>
<body><main><div class="eyebrow">UniCredit Research Lab · v0.1</div><h1>Historical evidence, with its limits visible</h1><p class="muted">Study {_escape(report.get('study_id',''))} · {_escape(report.get('phase',''))}</p><p class="banner">{banner}</p>
<section><h2>Candidate comparison</h2><p>Net simulated returns include the configured trading costs. Screening thresholds, uncertainty estimates and sample limitations are part of the result. The largest historical return is not automatic evidence of an edge.</p><div class="scroll"><table><thead><tr><th>Candidate</th><th>State</th><th>Net return</th><th>Trades</th><th>Active weeks</th><th>Drawdown</th><th>Mean daily return interval</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
{''.join(cards)}<section><h2>Run notes</h2><ul>{failures or '<li>No computation errors recorded.</li>'}</ul><details><summary>Run metadata</summary><pre>{_escape(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2,allow_nan=False))}</pre></details></section>
<footer>All account curves are simulations. Daily-close drawdown understates possible intraday losses. Confidence intervals depend on data, dependence, search and execution assumptions. No real broker connection exists. No trading strategy is guaranteed profitable.</footer></main></body></html>'''
    html_path.write_text(page)
    return {'html': str(html_path), 'json': str(json_path)}
