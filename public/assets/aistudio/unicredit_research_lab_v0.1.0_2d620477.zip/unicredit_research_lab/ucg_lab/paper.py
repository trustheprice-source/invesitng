"""File-fed simulated broker with immutable event IDs and no network path.

This component receives explicit orders and timestamped top-of-book snapshots.
It does not supply market data, schedule sessions or generate strategy signals.
Fills are hypothetical; displayed size is not a guarantee of execution.
"""

from __future__ import annotations

import json
import math
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import canonical_json


def _time(value=None):
    stamp = datetime.now(timezone.utc) if value is None else datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('Timestamp must include a UTC offset')
    return stamp.astimezone(timezone.utc)


def _positive(value, name, zero=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0 or (not zero and value == 0):
        raise ValueError(f'{name} must be a finite {"nonnegative" if zero else "positive"} number')
    return float(value)


class PaperBroker:
    """SQLite transactions prevent duplicate fills or partial state updates."""

    def __init__(self, path: str | Path, config: dict | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS paper_state (id INTEGER PRIMARY KEY CHECK(id=1), config TEXT NOT NULL, state TEXT NOT NULL)')
            row = db.execute('SELECT * FROM paper_state WHERE id=1').fetchone()
            if row:
                self.config = json.loads(row['config'])
                if config is not None and self._validate(config) != self.config:
                    raise ValueError('Cannot change an existing paper account configuration')
                return
            if config is None:
                raise ValueError('A new paper account requires explicit mode, data kind and frozen strategy hash')
            self.config = self._validate(config)
            state = {'cash': self.config['initial_cash'], 'quantity': 0, 'entry_cost': 0.0,
                     'orders': [], 'fills': [], 'quotes': {}, 'last_quote': None,
                     'eligible_for_live': False, 'mode': self.config['mode'], 'data_kind': self.config['data_kind']}
            db.execute('INSERT INTO paper_state VALUES (1,?,?)', (canonical_json(self.config), canonical_json(state)))

    @staticmethod
    def _validate(config):
        defaults = {'initial_cash': 10000.0, 'allocation_fraction': .25, 'commission_rate': .0005,
                    'minimum_commission': 3.0, 'slippage_bps_per_side': 2.0,
                    'latency_seconds': 60, 'max_quote_age_seconds': 60, 'max_signal_age_seconds': 300,
                    'mode': None, 'data_kind': None, 'frozen_hash': None}
        if set(config) - set(defaults):
            raise ValueError('Unknown paper configuration field')
        cfg = {**defaults, **config}
        if cfg['mode'] not in {'simulation', 'prospective'} or cfg['data_kind'] not in {'real', 'synthetic'}:
            raise ValueError('Explicit simulation/prospective mode and real/synthetic data kind required')
        if cfg['mode'] == 'prospective' and cfg['data_kind'] != 'real':
            raise ValueError('Synthetic observations cannot be called prospective market evidence')
        if not isinstance(cfg['frozen_hash'], str) or not cfg['frozen_hash']:
            raise ValueError('Frozen strategy identity required')
        for key in ('initial_cash', 'allocation_fraction', 'latency_seconds', 'max_quote_age_seconds', 'max_signal_age_seconds'):
            _positive(cfg[key], key)
        for key in ('commission_rate', 'minimum_commission', 'slippage_bps_per_side'):
            _positive(cfg[key], key, zero=True)
        if cfg['allocation_fraction'] > 1 or cfg['commission_rate'] > .1 or cfg['slippage_bps_per_side'] > 1000:
            raise ValueError('Paper exposure or cost parameter outside supported range')
        return cfg

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        return db

    @staticmethod
    def _read(db):
        return json.loads(db.execute('SELECT state FROM paper_state WHERE id=1').fetchone()['state'])

    @staticmethod
    def _write(db, state):
        db.execute('UPDATE paper_state SET state=? WHERE id=1', (canonical_json(state),))

    def _receipt_time(self, now):
        if now is not None and self.config['mode'] == 'prospective':
            raise ValueError('Explicit clock overrides are only permitted in simulation mode')
        return _time(now)

    def submit(self, order_id: str, side: str, quantity: int, decision_at: str, *, now=None) -> bool:
        if not isinstance(order_id, str) or not order_id or side not in {'buy','sell'}:
            raise ValueError('Nonempty order ID and buy/sell side required')
        if isinstance(quantity, bool) or not isinstance(quantity, int) or quantity <= 0:
            raise ValueError('Quantity must be positive whole shares')
        clock, decision = self._receipt_time(now), _time(decision_at)
        identity = {'order_id': order_id, 'side': side, 'quantity': quantity,
                    'decision_at': decision.isoformat(), 'frozen_hash': self.config['frozen_hash']}
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            state = self._read(db)
            prior = next((x for x in state['orders'] if x['order_id'] == order_id), None)
            if prior:
                if any(prior[k] != v for k,v in identity.items()):
                    raise ValueError('Order ID reused with different content')
                return False
            age = (clock - decision).total_seconds()
            if not 0 <= age <= self.config['max_signal_age_seconds']:
                raise ValueError('Signal is stale or from the future')
            if any(x['status'] == 'PENDING' for x in state['orders']):
                raise ValueError('Only one pending simulated order is supported')
            if side == 'buy' and state['quantity'] != 0:
                raise ValueError('One position at a time; pyramiding disabled')
            if side == 'sell' and quantity > state['quantity']:
                raise ValueError('Short selling is disabled')
            order = {**identity, 'submitted_at': clock.isoformat(),
                     'eligible_at': (clock + timedelta(seconds=self.config['latency_seconds'])).isoformat(),
                     'status':'PENDING'}
            state['orders'].append(order)
            self._write(db, state)
        return True

    def on_quote(self, quote: dict, *, now=None) -> list[dict]:
        required = {'quote_id','timestamp','symbol','bid','ask','bid_size','ask_size'}
        if set(quote) != required or not isinstance(quote['quote_id'], str) or not quote['quote_id']:
            raise ValueError('Quote requires exactly the documented fields and a nonempty ID')
        if quote['symbol'] != 'UCG':
            raise ValueError('Only UCG ordinary-share paper observations are accepted')
        bid, ask = _positive(quote['bid'],'bid'), _positive(quote['ask'],'ask')
        _positive(quote['bid_size'],'bid_size',zero=True)
        _positive(quote['ask_size'],'ask_size',zero=True)
        if bid > ask:
            raise ValueError('Crossed quote rejected')
        timestamp, clock = _time(quote['timestamp']), self._receipt_time(now)
        normalized = dict(quote, timestamp=timestamp.isoformat())
        encoded = canonical_json(normalized)
        fills = []
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            state = self._read(db)
            previous = state['quotes'].get(quote['quote_id'])
            if previous is not None:
                if previous != encoded:
                    raise ValueError('Quote ID reused with different content')
                return []
            age = (clock - timestamp).total_seconds()
            if not 0 <= age <= self.config['max_quote_age_seconds']:
                raise ValueError('Quote is stale or from the future')
            if state['last_quote'] and timestamp <= _time(state['last_quote']['timestamp']):
                raise ValueError('New quotes must advance event time')
            for order in state['orders']:
                if order['status'] != 'PENDING' or timestamp < _time(order['eligible_at']):
                    continue
                if (timestamp - _time(order['decision_at'])).total_seconds() > self.config['max_signal_age_seconds']:
                    order['status'] = 'EXPIRED'
                    order['reason'] = 'Original signal became stale before a hypothetical fill'
                    continue
                side, quantity = order['side'], order['quantity']
                depth = quote['ask_size'] if side == 'buy' else quote['bid_size']
                if depth < quantity:
                    continue
                slip = self.config['slippage_bps_per_side'] / 10000
                price = ask * (1 + slip) if side == 'buy' else bid * (1 - slip)
                notional = quantity * price
                fee = max(self.config['minimum_commission'], notional * self.config['commission_rate'])
                if side == 'buy':
                    cap = state['cash'] * self.config['allocation_fraction']
                    if notional > cap or notional + fee > state['cash']:
                        order['status'] = 'REJECTED'
                        order['reason'] = 'Insufficient cash or position allocation exceeded'
                        continue
                    state['cash'] -= notional + fee
                    state['quantity'] += quantity
                    state['entry_cost'] += notional + fee
                else:
                    if quantity > state['quantity']:
                        raise ValueError('Position changed; cannot oversell')
                    state['cash'] += notional - fee
                    state['entry_cost'] *= (state['quantity'] - quantity) / state['quantity']
                    state['quantity'] -= quantity
                order['status'] = 'FILLED'
                fill = {'order_id':order['order_id'], 'quote_id':quote['quote_id'], 'timestamp':timestamp.isoformat(),
                        'received_at':clock.isoformat(), 'side':side, 'quantity':quantity, 'price':price, 'fee':fee,
                        'mode':self.config['mode'], 'data_kind':self.config['data_kind'],
                        'fill_assumption':'Top-of-book snapshot with sufficient displayed size; hypothetical, no queue simulation',
                        'eligible_for_live':False}
                state['fills'].append(fill)
                fills.append(fill)
            state['quotes'][quote['quote_id']] = encoded
            state['last_quote'] = normalized
            self._write(db, state)
        return fills

    def cancel(self, order_id: str) -> bool:
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            state = self._read(db)
            order = next((x for x in state['orders'] if x['order_id'] == order_id),None)
            if order is None:
                raise ValueError('Unknown order')
            if order['status'] != 'PENDING':
                return False
            order['status'] = 'CANCELLED'
            self._write(db,state)
            return True

    def snapshot(self) -> dict:
        with self._connect() as db:
            state = self._read(db)
        state.pop('quotes',None)
        mark = state['last_quote']['bid'] if state['last_quote'] else 0
        state['marked_equity_before_exit_fees'] = state['cash'] + state['quantity'] * mark
        state['configuration'] = self.config
        return state
