"""Transactional experiment bookkeeping; a local guard, not tamper-proof storage."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .config import canonical_json


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class StudyLedger:
    # Name, NOT NULL flag and primary-key position; all columns are TEXT.
    _SCHEMA = {
        'trials': [('trial_id', 0, 1), ('candidate', 1, 0), ('dataset_hash', 1, 0),
                   ('config_hash', 1, 0), ('status', 1, 0), ('created_at', 1, 0),
                   ('completed_at', 0, 0), ('result', 0, 0), ('error', 0, 0)],
        'holdouts': [('period_key', 0, 1), ('frozen_hash', 1, 0), ('status', 1, 0),
                     ('claimed_at', 1, 0), ('completed_at', 0, 0), ('result', 0, 0), ('error', 0, 0)],
        'events': [('event_id', 0, 1), ('kind', 1, 0), ('payload', 1, 0), ('recorded_at', 1, 0)],
    }

    def __init__(self, path: str | Path, *, create: bool = False):
        self.path = Path(path).resolve()
        if create:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            # Exclusive creation never replaces an existing study's registry.
            with self.path.open('xb'):
                pass
        with self._connect(validate=not create) as db:
            if create:
                db.executescript('''
                    CREATE TABLE trials (
                        trial_id TEXT PRIMARY KEY, candidate TEXT NOT NULL,
                        dataset_hash TEXT NOT NULL, config_hash TEXT NOT NULL,
                        status TEXT NOT NULL, created_at TEXT NOT NULL,
                        completed_at TEXT, result TEXT, error TEXT);
                    CREATE TABLE holdouts (
                        period_key TEXT PRIMARY KEY, frozen_hash TEXT NOT NULL,
                        status TEXT NOT NULL, claimed_at TEXT NOT NULL,
                        completed_at TEXT, result TEXT, error TEXT);
                    CREATE TABLE events (
                        event_id TEXT PRIMARY KEY, kind TEXT NOT NULL,
                        payload TEXT NOT NULL, recorded_at TEXT NOT NULL);
                ''')

    @classmethod
    def _validate_schema(cls, db):
        for table, columns in cls._SCHEMA.items():
            rows = db.execute(f'PRAGMA table_info("{table}")').fetchall()
            actual = [(row['name'], row['type'].upper(), row['notnull'], row['pk']) for row in rows]
            expected = [(name, 'TEXT', required, primary) for name, required, primary in columns]
            if actual != expected:
                raise ValueError('Study ledger registry has an incompatible or missing schema; restore the original registry')

    def _connect(self, *, validate=True):
        # Every connection is noncreating, including after construction, so an
        # accidentally removed registry cannot be silently replaced on a read.
        try:
            db = sqlite3.connect(self.path.as_uri() + '?mode=rw', uri=True, timeout=30)
        except sqlite3.OperationalError as exc:
            raise ValueError('Study ledger registry is unavailable; restore the original registry before continuing') from exc
        db.row_factory = sqlite3.Row
        try:
            if validate:
                self._validate_schema(db)
        except (ValueError, sqlite3.DatabaseError) as exc:
            db.close()
            raise ValueError('Study ledger registry has an incompatible or missing schema; restore the original registry') from exc
        return db

    def register_trial(self, trial_id: str, candidate: dict, dataset_hash: str, config_hash: str, max_trials: int) -> bool:
        encoded = canonical_json(candidate)
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM trials WHERE trial_id=?', (trial_id,)).fetchone()
            if old:
                if (old['candidate'], old['dataset_hash'], old['config_hash']) != (encoded, dataset_hash, config_hash):
                    raise ValueError('Trial ID reused with changed candidate, data or configuration')
                return False
            if db.execute('SELECT COUNT(*) FROM trials').fetchone()[0] >= max_trials:
                raise ValueError('Registered search budget exhausted; no silent budget increase permitted')
            db.execute('INSERT INTO trials(trial_id,candidate,dataset_hash,config_hash,status,created_at) VALUES (?,?,?,?,?,?)',
                       (trial_id, encoded, dataset_hash, config_hash, 'RUNNING', utc_now()))
        return True

    def finish_trial(self, trial_id: str, result: dict) -> None:
        self._finish_trial(trial_id, 'COMPLETE', canonical_json(result), None)

    def fail_trial(self, trial_id: str, error: str) -> None:
        self._finish_trial(trial_id, 'FAILED', None, str(error))

    def _finish_trial(self, trial_id, status, result, error):
        with self._connect() as db:
            row = db.execute('UPDATE trials SET status=?,result=?,error=?,completed_at=? WHERE trial_id=? AND status=?',
                             (status, result, error, utc_now(), trial_id, 'RUNNING'))
            if row.rowcount != 1:
                raise ValueError('Trial is absent or already finalized')

    def trials(self) -> list[dict]:
        with self._connect() as db:
            rows = db.execute('SELECT * FROM trials ORDER BY created_at,trial_id').fetchall()
        output = []
        for row in rows:
            item = dict(row)
            item['candidate'] = json.loads(item['candidate'])
            item['result'] = json.loads(item['result']) if item['result'] else None
            output.append(item)
        return output

    def claim_holdout(self, period_key: str, frozen_hash: str) -> None:
        try:
            with self._connect() as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute('INSERT INTO holdouts(period_key,frozen_hash,status,claimed_at) VALUES (?,?,?,?)',
                           (period_key, frozen_hash, 'RUNNING', utc_now()))
        except sqlite3.IntegrityError as exc:
            raise ValueError('Final holdout already consumed; it is no longer an unseen test') from exc

    def finish_holdout(self, period_key: str, result: dict | None, error: str | None = None) -> None:
        with self._connect() as db:
            row = db.execute('UPDATE holdouts SET status=?,result=?,error=?,completed_at=? WHERE period_key=? AND status=?',
                             ('FAILED' if error else 'COMPLETE', canonical_json(result) if result is not None else None,
                              error, utc_now(), period_key, 'RUNNING'))
            if row.rowcount != 1:
                raise ValueError('Holdout absent or already finalized')

    def holdouts(self) -> list[dict]:
        with self._connect() as db:
            rows = db.execute('SELECT * FROM holdouts ORDER BY claimed_at').fetchall()
        return [{**dict(row), 'result': json.loads(row['result']) if row['result'] else None} for row in rows]

    def record_event(self, event_id: str, kind: str, payload: dict) -> bool:
        value = canonical_json(payload)
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT kind,payload FROM events WHERE event_id=?', (event_id,)).fetchone()
            if old:
                if tuple(old) != (kind, value):
                    raise ValueError('Event ID reused with conflicting content')
                return False
            db.execute('INSERT INTO events VALUES (?,?,?,?)', (event_id, kind, value, utc_now()))
        return True
