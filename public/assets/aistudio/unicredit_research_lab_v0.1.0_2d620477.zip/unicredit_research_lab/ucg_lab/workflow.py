"""Bounded chronological research, frozen final evaluation and paper handoff."""

from __future__ import annotations

import copy
import hashlib
import json
import os
import platform
from importlib import metadata
from dataclasses import replace
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn

from . import __version__
from .backtest import build_forward_labels, run_backtest
from .config import canonical_json, content_hash, load_config, validate_config
from .data import load_dataset
from .features import FEATURE_COLUMNS, build_features
from .ledger import StudyLedger, utc_now
from .models import find_analogs, fit_predict_model, walk_forward_splits
from .reporting import write_report
from .strategies import generate_rule_signals
from .validation import assess_evidence, summarize_performance


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def source_hash() -> str:
    digest = hashlib.sha256()
    for path in sorted(Path(__file__).parent.glob('*.py')):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def environment() -> dict:
    versions = {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__,
                'scikit_learn': sklearn.__version__, 'project': __version__}
    for package in ('scipy', 'joblib', 'threadpoolctl', 'lightgbm'):
        try:
            versions[package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            versions[package] = 'not_installed'
    return versions


def _dates(dataset) -> list[str]:
    return dataset.sessions['session_date'].astype(str).tolist()


def _slice(dataset, dates):
    dates = set(dates)
    sessions = dataset.sessions[dataset.sessions['session_date'].astype(str).isin(dates)].copy()
    start, end = sessions['open'].min(), sessions['close'].max()
    bars = dataset.bars[dataset.bars['timestamp'].ge(start) & dataset.bars['timestamp'].lt(end)].copy()
    context = dataset.context
    news = dataset.news
    if context is not None:
        context = context[context['available_at'].le(end)].copy()
    if news is not None:
        news = news[news['available_at'].le(end)].copy()
    return replace(dataset, bars=bars.reset_index(drop=True), sessions=sessions.reset_index(drop=True), context=context, news=news)


def _labelled(dataset, config):
    features = build_features(dataset, config['features'])
    labels = build_forward_labels(features, dataset.bars, dataset.sessions, config['execution'])
    return features.merge(labels, on='decision_time', how='left', validate='one_to_one')


def _signals(labelled, train_dates, test_dates, candidate):
    test = labelled[labelled['session_date'].isin(test_dates)].copy()
    if test.empty:
        raise ValueError('No completed features in evaluation period')
    if candidate['kind'] == 'rule':
        return generate_rule_signals(test, candidate['name'], candidate['parameters'])
    train = labelled[labelled['session_date'].isin(train_dates)].copy()
    predictions = fit_predict_model(train, test, FEATURE_COLUMNS, candidate['name'], candidate['parameters'])
    return pd.DataFrame({'decision_time': test['decision_time'].to_numpy(), 'score': predictions})


def _evaluate(dataset, labelled, config, candidate, splits, out):
    current_cash = config['execution']['initial_cash']
    equity_frames, trade_frames, signal_frames, events, fold_info = [], [], [], [], []
    for fold, (train_dates, test_dates) in enumerate(splits):
        period = _slice(dataset, test_dates)
        if current_cash == 0:
            # Bankruptcy is absorbing across folds as well as within a backtest.
            # Keep every evaluation session without fitting or submitting new signals.
            equity_frames.append(pd.DataFrame([
                dict(session_date=session.session_date, equity=0., daily_return=0., net_pnl=0., trade_count=0)
                for session in period.sessions.itertuples(index=False)
            ]))
            events.extend(dict(type='account_exhausted', timestamp=pd.Timestamp(session.open).isoformat(),
                               session_date=session.session_date,
                               reason='zero equity; trading disabled without recapitalization',
                               daily_return_convention='unchanged zero equity records zero daily return')
                          for session in period.sessions.itertuples(index=False))
        else:
            signal = _signals(labelled, train_dates, test_dates, candidate)
            execution = dict(config['execution'], initial_cash=current_cash, score_threshold=candidate['score_threshold'])
            simulation = run_backtest(period.bars, period.sessions, signal, execution)
            current_cash = float(simulation.equity.iloc[-1]['equity'])
            equity_frames.append(simulation.equity)
            trade_frames.append(simulation.trades)
            signal_frames.append(signal)
            events.extend(simulation.events)
        fold_info.append({'fold': fold, 'train_first': train_dates[0], 'train_last': train_dates[-1],
                          'test_first': test_dates[0], 'test_last': test_dates[-1]})
    if not equity_frames:
        raise ValueError('No walk-forward evaluation periods: acquire more sessions or predeclare another design')
    equity = pd.concat(equity_frames, ignore_index=True)
    nonempty_trades = [frame for frame in trade_frames if not frame.empty]
    trades = pd.concat(nonempty_trades, ignore_index=True) if nonempty_trades else trade_frames[0].iloc[:0].copy()
    signals = pd.concat(signal_frames, ignore_index=True)
    out.mkdir(parents=True, exist_ok=True)
    equity.to_csv(out / 'equity.csv', index=False)
    trades.to_csv(out / 'trades.csv', index=False)
    signals.to_csv(out / 'signals.csv', index=False)
    write_json(out / 'events.json', events)
    stats_config = {**config['research'], 'initial_cash': config['execution']['initial_cash'],
                    'family_size': config['research']['max_trials']}
    metrics = summarize_performance(equity, trades, stats_config)
    return metrics, equity, fold_info


def _evidence(metrics, dataset, config, phase):
    evidence = assess_evidence(metrics, dataset.manifest['data_kind'], phase, config['criteria'], dataset.manifest['provenance_verified'])
    if dataset.manifest['data_kind'] != 'synthetic':
        for flag in ('broker_costs_verified', 'risk_mandate_approved'):
            if not config['assumptions'][flag]:
                evidence['failed_checks'].append(flag)
                evidence['status'] = 'RESEARCH_ONLY'
    evidence['eligible_for_live'] = False
    evidence['execution_warning'] = 'Minute-bar and quote-snapshot fills are approximations; queue, depth and transient spread behavior are not reproduced.'
    evidence['drawdown_warning'] = 'Reported drawdown uses daily ending equity; it does not bound intraday or future losses.'
    return evidence


def _study_state(study):
    study = Path(study).resolve()
    StudyLedger(study / 'ledger.sqlite', create=False)
    state = json.loads((study / 'study.json').read_text())
    config = validate_config(json.loads((study / 'config.snapshot.json').read_text()))
    if state['config_hash'] != content_hash(config):
        raise ValueError('Study configuration was modified; experiment identity is invalid')
    if state['source_hash'] != source_hash():
        raise ValueError('Source code changed since this study; do not silently reuse prior evidence')
    if state['environment'] != environment():
        raise ValueError('Dependency environment changed since registration; preserve prior evidence')
    dataset = load_dataset((study / state['manifest_relative']).resolve())
    if state['dataset_hash'] != dataset.dataset_hash:
        raise ValueError('Dataset bytes changed since registration')
    return study, state, config, dataset


def run_research(manifest_path: str | Path, config_path: str | Path, out: str | Path) -> dict:
    config, dataset = load_config(config_path), load_dataset(manifest_path)
    out = Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    dates = _dates(dataset)
    n_holdout = config['research']['holdout_sessions']
    if len(dates) <= n_holdout + config['research']['train_sessions']:
        raise ValueError('Not enough sessions for training, development evaluation and reserved holdout')
    development_dates, holdout_dates = dates[:-n_holdout], dates[-n_holdout:]
    expected = {'study_id': config['study_id'], 'dataset_hash': dataset.dataset_hash,
                'config_hash': content_hash(config), 'source_hash': source_hash()}
    if (out / 'study.json').exists():
        old = json.loads((out / 'study.json').read_text())
        if any(old[key] != value for key, value in expected.items()):
            raise ValueError('Existing study has different data, config or source; preserve its history')
        if old['environment'] != environment():
            raise ValueError('Existing study has a different dependency environment')
        ledger = StudyLedger(out / 'ledger.sqlite', create=False)
    else:
        if any(out.iterdir()):
            raise ValueError('New study requires an empty directory; preserve existing artifacts and ledger registry')
        ledger = StudyLedger(out / 'ledger.sqlite', create=True)
        state = {**expected, 'created_at': utc_now(), 'environment': environment(),
                 'manifest_relative': os.path.relpath(Path(manifest_path).resolve(), out),
                 'development_dates': development_dates, 'holdout_dates': holdout_dates}
        write_json(out / 'study.json', state)
        write_json(out / 'config.snapshot.json', config)
        write_json(out / 'data_audit.json', dataset.audit)
    if ledger.holdouts():
        raise ValueError('Holdout consumed; development cannot continue while calling this period unseen')
    development = _slice(dataset, development_dates)
    labelled = _labelled(development, config)
    splits = walk_forward_splits(development_dates, config['research']['train_sessions'], config['research']['test_sessions'])
    for candidate in config['candidates']:
        cid = candidate['id']
        if not ledger.register_trial(cid, candidate, dataset.dataset_hash, expected['config_hash'], config['research']['max_trials']):
            continue
        try:
            metrics, equity, folds = _evaluate(development, labelled, config, candidate, splits, out / 'development' / cid)
            result = {'candidate': candidate, 'metrics': metrics, 'evidence': _evidence(metrics, dataset, config, 'development'),
                      'folds': folds, 'equity': equity.to_dict('records')}
            ledger.finish_trial(cid, result)
        except Exception as exc:
            ledger.fail_trial(cid, f'{type(exc).__name__}: {exc}')
    trials = ledger.trials()
    report = {**expected, 'created_at': utc_now(), 'environment': environment(), 'phase': 'development',
              'data_kind': dataset.manifest['data_kind'], 'eligible_for_live': False,
              'assumptions': config['assumptions'], 'execution': config['execution'],
              'holdout': {'first': holdout_dates[0], 'last': holdout_dates[-1], 'sessions': n_holdout, 'evaluated': False},
              'registered_trials': len(trials), 'search_budget': config['research']['max_trials'],
              'results': [row['result'] for row in trials if row['status'] == 'COMPLETE'],
              'failures': [{'id': row['trial_id'], 'status': row['status'], 'error': row['error']} for row in trials if row['status'] != 'COMPLETE'],
              'notes': ['Holdout data was structurally audited but no holdout features or performance were used for development.',
                        'Daily equity carries across evaluation folds; each session ends flat.',
                        'Fixed-horizon regression targets do not include the simulator stop policy.',
                        'No-trade nominal cash reference is 0%; cash interest, personal taxes, data and operating fees excluded.',
                        'Bootstrap intervals are approximate screening diagnostics, not a probability of future profit.']}
    write_report(report, out / 'development')
    return report


def freeze_candidate(study: str | Path, candidate_id: str) -> Path:
    study, state, config, dataset = _study_state(study)
    path = study / 'frozen.json'
    if path.exists():
        raise ValueError('A candidate is already frozen; do not overwrite its evidence identity')
    ledger = StudyLedger(study / 'ledger.sqlite', create=False)
    if ledger.holdouts():
        raise ValueError('This final period has already been consumed')
    rows = [row for row in ledger.trials() if row['trial_id'] == candidate_id and row['status'] == 'COMPLETE']
    if len(rows) != 1:
        raise ValueError('Candidate must have a completed registered development trial')
    frozen = {'schema_version': 1, 'created_at': utc_now(), 'study_id': state['study_id'],
              'dataset_hash': dataset.dataset_hash, 'config_hash': state['config_hash'],
              'source_hash': state['source_hash'], 'candidate': rows[0]['candidate'],
              'holdout_dates': state['holdout_dates'], 'data_kind': dataset.manifest['data_kind'],
              'eligible_for_live': False, 'training_policy': 'Fit once on the last declared training window before holdout; no adaptation inside final test.',
              'environment': environment()}
    frozen['artifact_hash'] = content_hash(frozen)
    write_json(path, frozen)
    ledger.record_event('freeze', 'freeze', frozen)
    return path


def _frozen(study, state):
    frozen = json.loads((study / 'frozen.json').read_text())
    supplied = frozen.pop('artifact_hash', None)
    if supplied != content_hash(frozen):
        raise ValueError('Frozen artifact integrity check failed')
    frozen['artifact_hash'] = supplied
    for key in ('dataset_hash', 'config_hash', 'source_hash'):
        if frozen[key] != state[key]:
            raise ValueError(f'Frozen {key} does not match study')
    if frozen['holdout_dates'] != state['holdout_dates']:
        raise ValueError('Frozen holdout dates were changed')
    return frozen


def run_holdout(study: str | Path) -> dict:
    study, state, config, dataset = _study_state(study)
    frozen = _frozen(study, state)
    ledger = StudyLedger(study / 'ledger.sqlite', create=False)
    key = content_hash({'dataset': dataset.dataset_hash, 'period': state['holdout_dates']})
    ledger.claim_holdout(key, frozen['artifact_hash'])
    try:
        labelled = _labelled(dataset, config)
        train_dates = state['development_dates'][-config['research']['train_sessions']:]
        test_dates = state['holdout_dates']
        metrics, equity, folds = _evaluate(dataset, labelled, config, frozen['candidate'], [(train_dates, test_dates)], study / 'holdout')
        evidence = _evidence(metrics, dataset, config, 'holdout')
        result = {'candidate': frozen['candidate'], 'metrics': metrics, 'evidence': evidence,
                  'folds': folds, 'equity': equity.to_dict('records')}
        report = {'study_id': state['study_id'], 'phase': 'holdout', 'data_kind': dataset.manifest['data_kind'],
                  'eligible_for_live': False, 'frozen_hash': frozen['artifact_hash'], 'created_at': utc_now(),
                  'results': [result], 'failures': [], 'execution': config['execution'], 'assumptions': config['assumptions'],
                  'notes': ['Final holdout consumed once; do not tune against this result.', frozen['training_policy']]}
        write_report(report, study / 'holdout')
        ledger.finish_holdout(key, report)
        return report
    except Exception as exc:
        ledger.finish_holdout(key, None, error=f'{type(exc).__name__}: {exc}')
        raise


def export_handoff(study: str | Path) -> Path:
    study, state, config, dataset = _study_state(study)
    frozen = _frozen(study, state)
    completed = [row for row in StudyLedger(study / 'ledger.sqlite', create=False).holdouts() if row['status'] == 'COMPLETE']
    if len(completed) != 1:
        raise ValueError('Complete the one-shot frozen final evaluation before exporting a paper handoff')
    evidence = completed[0]['result']['results'][0]['evidence']
    result = {'schema_version': 1, 'symbol': 'UCG', 'currency': 'EUR', 'mode': 'paper_only',
              'data_kind': dataset.manifest['data_kind'], 'eligible_for_live': False,
              'frozen_hash': frozen['artifact_hash'], 'dataset_hash': dataset.dataset_hash,
              'source_hash': state['source_hash'], 'candidate': frozen['candidate'], 'evidence': evidence,
              'execution': config['execution'], 'created_at': utc_now(),
              'allowed_actions': ['read_status', 'run_tests', 'record_paper_orders_and_quotes', 'report_results'],
              'forbidden_actions': ['real_orders', 'withdrawals', 'change_risk_policy', 'rewrite_evidence', 'bypass_data_access'],
              'limitations': ['No official OpenClaw broker plugin or live integration is implied.',
                              'This is a versioned JSON handoff contract, not an installable OpenClaw skill.',
                              'A live read-only feed and frozen signal service still need integration and validation.',
                              'Unqualified and synthetic strategies remain explicitly research/demo in paper logs.']}
    path = study / 'paper_handoff.json'
    write_json(path, result)
    return path


def inspect_analogs(study: str | Path, decision_at: str | None = None, max_cases: int = 10) -> dict:
    """Explain a development-period state without revealing final outcomes."""
    study, state, config, dataset = _study_state(study)
    if not isinstance(max_cases, int) or not 1 <= max_cases <= 50:
        raise ValueError('max_cases must be between 1 and 50')
    development = _slice(dataset, state['development_dates'])
    labelled = _labelled(development, config)
    if decision_at is None:
        query = labelled.iloc[-1]
    else:
        timestamp = pd.Timestamp(decision_at)
        if timestamp.tzinfo is None:
            raise ValueError('Decision time requires an explicit UTC offset')
        choices = labelled[labelled['decision_time'].eq(timestamp.tz_convert('UTC'))]
        if choices.empty:
            raise ValueError('Decision must be an existing completed development bar; final-period inspection is unavailable')
        query = choices.iloc[0]
    cases = find_analogs(labelled, query, FEATURE_COLUMNS, max_cases)
    conditions = {column: (float(query[column]) if pd.notna(query[column]) else None) for column in FEATURE_COLUMNS}
    return {'phase':'development_explanation','data_kind':dataset.manifest['data_kind'],
            'decision_time':query['decision_time'].isoformat(),'conditions':conditions,'cases':cases,
            'eligible_for_live':False,'notice':'Similar earlier cases, including losses, are explanatory examples and do not prove predictive value.'}
